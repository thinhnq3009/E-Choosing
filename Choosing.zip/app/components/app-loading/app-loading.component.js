(function () {
    angular.module("choosing-app").component("appLoading", {
        templateUrl: "components/app-loading/app-loading.template.html",
        controller: ($scope, $rootScope) => {},
    });
})();
