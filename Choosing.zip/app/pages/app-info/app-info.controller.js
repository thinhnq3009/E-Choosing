angular.module("choosing-app").controller("infoController", [
    "$scope",
    "$rootScope",
    ($scope, $rootScope) => {
        console.log($scope);
    },
]);
