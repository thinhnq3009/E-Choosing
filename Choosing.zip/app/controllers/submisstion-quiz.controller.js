(function () {
    angular.module("choosing-app").controller("submissionQuizController", [
        "$scope",
        "$rootScope",
        "$http",
        ($scope, $rootScope, $http) => {
            
        },
    ]);
})();
